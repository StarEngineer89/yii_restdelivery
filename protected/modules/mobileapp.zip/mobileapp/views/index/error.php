

<div class="pad10 text-danger">
 <?php echo $msg?>
</div>
